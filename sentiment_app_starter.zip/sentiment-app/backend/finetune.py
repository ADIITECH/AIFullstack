
import argparse
import json
import random
import os
import numpy as np
import torch
from transformers import Trainer, TrainingArguments, AutoModelForSequenceClassification, AutoTokenizer, DataCollatorWithPadding
from datasets import load_dataset, Dataset

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

def load_data(file_path):
    with open(file_path) as f:
        data = [json.loads(line) for line in f]
    return Dataset.from_list(data)

def main(args):
    set_seed()

    dataset = load_data(args.data)
    label_map = {"positive": 1, "negative": 0}
    dataset = dataset.map(lambda x: {"label": label_map[x["label"]]})

    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
    tokenized_dataset = dataset.map(lambda x: tokenizer(x["text"], truncation=True), batched=True)

    model = AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=2)
    training_args = TrainingArguments(
        output_dir="./model",
        num_train_epochs=args.epochs,
        per_device_train_batch_size=8,
        learning_rate=args.lr,
        logging_dir="./logs",
        save_strategy="epoch"
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_dataset,
        tokenizer=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
    )

    trainer.train()
    trainer.save_model("./model")
    tokenizer.save_pretrained("./model")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, required=True)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=3e-5)
    args = parser.parse_args()
    main(args)
