
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
import os

def load_model_and_tokenizer():
    model_dir = "./model"
    if os.path.exists(model_dir) and os.listdir(model_dir):
        model = AutoModelForSequenceClassification.from_pretrained(model_dir)
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
    else:
        model = AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased-finetuned-sst-2-english")
        tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased-finetuned-sst-2-english")
    return model, tokenizer

def predict_sentiment(model, tokenizer, text):
    pipe = pipeline("sentiment-analysis", model=model, tokenizer=tokenizer)
    result = pipe(text)[0]
    return result['label'].lower(), result['score']
