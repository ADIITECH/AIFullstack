
from fastapi import FastAPI, Request
from pydantic import BaseModel
from model_loader import load_model_and_tokenizer, predict_sentiment

app = FastAPI()

model, tokenizer = load_model_and_tokenizer()

class TextInput(BaseModel):
    text: str

@app.post("/predict")
def predict(data: TextInput):
    label, score = predict_sentiment(model, tokenizer, data.text)
    return {"label": label, "score": round(score, 4)}
