
import { useState } from 'react';
import './App.css';

function App() {
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);

  const predict = async () => {
    const res = await fetch('http://localhost:8000/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await res.json();
    setResult(data);
  };

  return (
    <div className="App">
      <h2>Sentiment Analyzer</h2>
      <textarea rows="5" cols="50" value={text} onChange={e => setText(e.target.value)} />
      <br />
      <button onClick={predict}>Predict</button>
      {result && <div><strong>{result.label}</strong> ({result.score})</div>}
    </div>
  );
}

export default App;
